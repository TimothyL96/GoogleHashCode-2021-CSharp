﻿using Google.OrTools.LinearSolver;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace GoogleHashCode2021
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");

            Problem p = new Problem();

            var results = OneEach(p);

            p.WriteToFile(results);
        }

        static List<Schedule> OneEach(Problem p)
        {
            var schedules = new List<Schedule>();

            int halfPeriod = p.Period / 2;
            var min = 1;
            var max = halfPeriod - 1;

            foreach (var item in p.Intersections)
            {
                var schedule = new Schedule
                {
                    NrIncomingStreets = item.EndStreets.Count,
                };

                bool getMax = false;
                var val = min;
                var total = 0;

                foreach (var streetID in item.EndStreets)
                {
                    var street = p.Streets.Where(x => x.ID == streetID).FirstOrDefault();
                    schedule.StreetLightSchedule.Add(street.Name, val);

                    total += val;

                    if (total >= p.Period)
                    {
                        break;
                    }

                    if (getMax)
                    {
                        getMax = false;

                        if (max > 0)
                        {
                            max--;
                        }
                        else
                        {
                            max = halfPeriod - 1;
                        }

                        val = min;
                    }
                    else
                    {
                        getMax = true;
                        if (min < halfPeriod)
                        {
                            min++;
                        }
                        else
                        {
                            min = 1;
                        }

                        val = max;
                    }


                }

                schedules.Add(schedule);
            }

            return schedules;
        }

        static void Linear()
        {
            // GLOP Linear Solver
            // SCIP Integer solver
            Solver solver = Solver.CreateSolver("GLOP");

            Variable x = solver.MakeBoolVar("x");
            Variable y = solver.MakeNumVar(0.0, double.PositiveInfinity, "y");

            solver.Add(x + 2 * y <= 14.0);
            solver.Add(3 * x - y >= 0.0);

            solver.Maximize(3 * x + 4 * y);
            // Time needed = i1 + i2
            // Steps <= period
            Solver.ResultStatus resultStatus = solver.Solve();

            if (resultStatus != Solver.ResultStatus.OPTIMAL)
            {
                Console.WriteLine("No optimal solution");
                return;
            }

            Console.WriteLine("Solution:", solver.Objective().Value());
        }
    }
}
