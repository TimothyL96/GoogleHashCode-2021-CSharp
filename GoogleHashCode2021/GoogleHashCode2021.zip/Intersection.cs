﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GoogleHashCode2021
{
    public class Intersection
    {
        public int ID { get; set; }
        public List<int> StartStreets { get; set; }
        public List<int> EndStreets { get; set; }
    }
}
