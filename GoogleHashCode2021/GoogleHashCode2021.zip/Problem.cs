﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace GoogleHashCode2021
{
    public class Problem
    {
        public int ID { get; set; }
        public int Period { get; set; }
        public int NrIntersections { get; set; }
        public int NrStreets { get; set; }
        public int NrCars { get; set; }
        public int ScorePerCar { get; set; }

        public List<Street> Streets { get; set; } = new List<Street>();
        public List<Car> Cars { get; set; } = new List<Car>();
        public List<Intersection> Intersections{ get; set; } = new List<Intersection>();

        public Problem()
        {
            var dataFile = @"D:\Timothy\Desktop\answer\d.txt";

            try
            {
                List<string> lines = File.ReadAllLines(dataFile).ToList();

                var index = 0;
                foreach (var line in lines)
                {
                    if (index == 0)
                    {
                        var firstLine = line.Split(' ');
                        Period = int.Parse(firstLine[0]);
                        NrIntersections = int.Parse(firstLine[1]);
                        NrStreets = int.Parse(firstLine[2]);
                        NrCars = int.Parse(firstLine[3]);
                        ScorePerCar = int.Parse(firstLine[4]);
                    }
                    else if (index <= NrStreets)
                    {
                        var streetLine = line.Split(' ');
                        var street = new Street
                        {
                            ID = index - 1,
                            StartIntersection = int.Parse(streetLine[0]),
                            EndIntersection= int.Parse(streetLine[1]),
                            Name = streetLine[2],
                            Duration = int.Parse(streetLine[3]),
                        };

                        Streets.Add(street);
                    }
                    else
                    {
                        var carLine = line.Split(' ');
                        var car = new Car
                        {
                            ID = Cars.Count,
                            Paths = Street.GetStreetID(Streets, carLine.Skip(1).ToList()),
                        };

                        Cars.Add(car);
                    }
   
                    index++;
                }

                for (int i = 0; i < NrIntersections; i++)
                {
                    var intersection = new Intersection
                    {
                        ID = i,
                        StartStreets = Street.GetStartIntersection(Streets, i),
                        EndStreets = Street.GetEndIntersection(Streets, i),
                    };

                    Intersections.Add(intersection);
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void WriteToFile(List<Schedule> schedules)
        {
            var answerFile = @"D:\Timothy\Desktop\answer\answer_d.txt";

            List<string> answer = new List<string>()
            {
                schedules.Count().ToString(),
            };

            var key = 0;
            foreach (var item in schedules)
            {
                answer.Add(key.ToString());
                answer.Add(item.NrIncomingStreets.ToString());

                foreach (KeyValuePair<string, int> keyValues in item.StreetLightSchedule)
                {
                    var dictString = keyValues.Key + " " + keyValues.Value;
                    answer.Add(dictString);
                }

                key++;
            }

            try
            {
                File.WriteAllLines(answerFile, answer);
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}
